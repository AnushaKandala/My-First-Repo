public class Inheritence  {


    public static void main(String[] args) {

        Child child = new Child();

        child.childName="childName";
        child.employeeFirstName="employeeFirstName";
    }
}
