
public class FirstJavaProgram {

    public static void main(String args[]){  /*starts from here*/

        System.out.println("Hello class...!");


    }

}
