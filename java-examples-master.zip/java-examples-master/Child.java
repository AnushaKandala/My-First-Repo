public class Child extends Employee {

    //here parent is Employee class
    //child class is Child

    //using extends keyword we would use inhertence

    public String childName;
}
